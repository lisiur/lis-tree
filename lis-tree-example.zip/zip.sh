zip -r lis-tree.zip components static
zip -r lis-tree-example.zip .
